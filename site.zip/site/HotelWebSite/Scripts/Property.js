﻿var PropertyDetails = function () {
    var self = this;
    self.Name = "";
    self.Proprietor = "";
    self.GST = "";
    self.Address1 = "";
    self.Address2 = "";
    self.Pin = "";
    self.Phone = "";
    self.Mobile = "";
    self.City = "";
    self.State = "";
    self.Description="";
}

$(document).ready(function () {

    $('#submit').click(function () {
        var frmdata = new PropertyDetails();
        frmdata.Name = $("#hname").val();
        frmdata.Proprietor = $("#proprietor").val();
        frmdata.GST = $("#GST").val();
        frmdata.Address1 = $("#Address1").val();
        frmdata.Address2 = $("#Address2").val();
        frmdata.Pin = $("#pin").val();
        frmdata.Phone = $("#phone").val();
        frmdata.Mobile = $("#mobile").val();
        frmdata.City = $("#City").val();
        frmdata.State = $("#state").val();
        frmdata.Description = $("#desc").val();
        debugger;
        var xhr = $.ajax(
            {
                //url: 'SaveProperty', //this is the same Application Controller action method
                url: 'http://localhost:8081/api/Property/SaveHotel',
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                //data: JSON.stringify({ 'hotel': JSON.stringify(frmdata) }), //in same controller
                data: JSON.stringify(JSON.stringify(frmdata)), //for api
                type: "POST",
                beforeSend: function () {
                    console.log("Details recieved ajax started");
                },
                success: function (res) {
                    debugger;
                    alert("Details Strored Successfully");
                },
                error: function (x, y, z) {
                    alert("Data fetch Error" +z);
                },
                complete: function () {
                    //alert("Completed like finally");
                }
            });
    });


   
});
