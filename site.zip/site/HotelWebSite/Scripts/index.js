﻿//$(document).ready(function () {

//    $('#GetList').click(function () {
//        var xhr = $.ajax(   // request url
//            {
//                //url: 'https://jsonplaceholder.typicode.com/posts',
//                url:'shttps://www.googleapis.com/travelpartner/v2.0/4200042/hotels',
//                data: "abc",
//                type: "GET",
//                beforeSend: function () {
//                    console.log("ajax starting");
//                },
//                success: function (data) {
//                    debugger;
//                    $("#para").html('');

//                    $.each(data, function () {
//                        var item = this;
//                        $("#para").append("<p style='float:left'>" + item.id + "</p><p 'float:right'>" + item.title + "</p>")
//                    });
//                },
//                error: function (x, y, z) {
//                    //if(x.status != 0)
//                    //    alert("Fetching Data from GOOGLE API Has an Error");
//                    //else alert("Successfully getting Data");
//                    $('#succes').show();
//                    $('#succes').hide();
//                }
//            });
//    });
//});


var IndexMasterVM = (function () {
    var ListCities = ko.observableArray([]);
    var Hotel = ko.observable(new Hotels());


    return 
}());

var Hotels = function () {
    this.Location = "";
    this.CheckIn = "";
    this.CheckOut = "";
}


$(document).ready(function () {

    $('#search').click(function () {
        var frmdata = new Hotels();
        frmdata.Location = $("#City").val();
        frmdata.CheckIn = $("#checkin").val();
        frmdata.CheckOut = $("#checkout").val();
        debugger;
        var xhr = $.ajax(
            {
                url: '/Search/HotelSearchByModel',
                data: frmdata,
                type: "POST",
                beforeSend: function () {
                    console.log("ajax starting");
                },
                success: function (res) {
                    debugger;
                    //$("#searchdiv").html('').html(res);
                    //$("#para").html(res);
                    //$.each(res, function() {
                    //    var datas = this;
                    //    $.each(datas, function () {
                    //        var item = this;
                    //        var str = "<p>" + item.Location + "</p>" + "<p>" + item.CheckIn + "</p>" + "<p>" + item.CheckOut + "</p><br/><br/>";
                    //        //salert(str);
                    //        $("#para").append(str);
                    //    });
                        
                    //});
                    AjaxSuccessCall(res);
                },
                error: function (x, y, z) {
                        alert("Data fetch Error");
                }
            });
    });


    //documentReady Closing Write all meth
    function AjaxSuccessCall(res) {
        alert("Data submitted for Search");      
        window.location.href = 'Search/HotelSearchByModel';
    }
});
